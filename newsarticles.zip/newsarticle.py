# -*- coding: utf-8 -*-
"""
Created on Sun Apr 22 07:54:51 2018

@author: Wayhe
"""

class newsarticle:
    publisher = None
    title = None
    discription = None
    keywords = None
    publish_date = None
    url = None
    mediaType=None
    content = None
    related = None
    
    def __init__(self, pb, kws, pd, url, title, discription, cnt, mediaType, related):
        self.publisher = pb
        self.keywords = kws
        self.publish_date = pd
        self.url= url
        self.title = title
        self.discription = discription
        self.content = cnt
        self.mediaType = mediaType
        self.related = related
        
    def getPublisher(self):
        return self.publisher
    
    def getKeywords(self):
        return self.keywords
    
    def getPublishDate(self):
        return self.publish_date
    
    def getUrl(self):
        return self.url
    
    def getContent(self):
        return self.content
    
    def getTitle(self):
        return self.title
    
    def getDiscriptioin(self):
        return self.discription
    
    def getRelated(self):
        return self.related
    
    def getMediaType(self):
        return self.mediaType
            
    def setKeywords(self, kws):
        self.keywords = kws
    
    def setPublishDate(self, pd):
        self.publish_date = pd
    
    def setUrl(self, url):
        self.url = url
    
    def setContent(self, ct):
        self.content = ct 
    
    def setTitle(self, title):
        self.title = title
    
    def setDiscriptioin(self, discription):
        self.discription = discription
    
    def setRelated(self, related):
        self.related = related
    
    def setMediaType(self, mediaType):
        self.mediaType = mediaType
        