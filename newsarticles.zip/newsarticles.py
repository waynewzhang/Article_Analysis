# -*- coding: utf-8 -*-
"""
Created on Sun Apr 22 07:54:51 2018

@author: Wayhe
"""
import newsarticle as ar

class newsarticles:
    all_articles = None
    articleKeys = None
    
    def __init__(self):
        self.all_articles = dict()
        self.articleKeys = dict()
    

    def get_publisher(self, pb):
        if pb not in self.all_articles:
            self.all_articles[pb]=[]
        else:
            self.all_articles[pb]
        return self.all_articles[pb]
            
    def addArticle(self, pb, kws, pd, url, title, discription, cnt, mediaType, related):
        article_list = self.get_publisher(pb)
        article = ar.newsarticle(pb, kws, pd, url, title, discription, cnt, mediaType, related)
        article_list.append(article)
        self.articleKeys[url] = len(self.articleKeys) + 1
        print(url, self.articleKeys[url])
        return article
        
    def getAllArticles(self):
        return self.all_articles
    
    def hasItem(self, key):
        f = False
        if key in self.articleKeys:
            f = True
        return f
    
    def printSize(self):
        print(len(self.articleKeys))
        for item in self.all_articles:
            print(item, len(self.all_articles[item]))
            